﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form4 : Form
    {
        int click = 0;
        int score;
        int indx;
        public string[] newArr3 { get; set; }
        public string[] newArr4 = new string[1];
        public Form4(int score1)
        {
            score = score1;
            InitializeComponent();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

            var rndm = new Random();

            indx = rndm.Next(0, newArr3.Length);

            List<char> ltrsLst = new List<char>(newArr3[indx]);
            var rnd = new Random();
            while (ltrsLst.Count > 0)
            {
                int index = rnd.Next(0, ltrsLst.Count);
                label2.Text += Convert.ToString((ltrsLst[index]) + " ");
                ltrsLst.RemoveAt(index);
            }

            int k = 0;
            for (int i = 0; i < newArr4.Length; i++)
            {
                if (newArr3[k] != newArr3[indx])
                {
                    newArr4[i] = newArr3[k];
                    k++;
                }
                else
                {
                    newArr4[i] = newArr3[k + 1];
                    k += 2;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == newArr3[indx])
            {
                if (click != 1)
                {
                    score++;
                }
            }
                Form5 frm = new Form5(score);
                frm.newArr4 = newArr4;
                frm.Show();
                this.Hide();           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = newArr3[indx];
            click = 1;
        }
    }
}
