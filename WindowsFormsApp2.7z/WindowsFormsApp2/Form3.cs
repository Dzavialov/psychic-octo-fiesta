﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form3 : Form
    {
        int click = 0;
        int score;
        int indx;
        public string[] newArr2 { get; set; }
        public string[] newArr3 = new string[2];
        public Form3(int score1)
        {
            score = score1;
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            var rndm = new Random();

            indx = rndm.Next(0, newArr2.Length);

            List<char> ltrsLst = new List<char>(newArr2[indx]);
            var rnd = new Random();
            while (ltrsLst.Count > 0)
            {
                int index = rnd.Next(0, ltrsLst.Count);
                label2.Text += Convert.ToString((ltrsLst[index]) + " ");
                ltrsLst.RemoveAt(index);
            }

            int k = 0;
            for (int i = 0; i < newArr3.Length; i++)
            {
                if (newArr2[k] != newArr2[indx])
                {
                    newArr3[i] = newArr2[k];
                    k++;
                }
                else
                {
                    newArr3[i] = newArr2[k + 1];
                    k += 2;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == newArr2[indx])
            {
                if (click != 1)
                {
                    score++;
                }
            }          
                Form4 frm = new Form4(score);
                frm.newArr3 = newArr3;
                frm.Show();
                this.Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = newArr2[indx];
            click = 1;
        }
    }
}
