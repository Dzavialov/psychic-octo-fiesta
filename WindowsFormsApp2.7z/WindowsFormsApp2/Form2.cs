﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{    public partial class Form2 : Form
    {
        int click = 0;
        int score;
        int indx;
        
        public string[] newArr { get; set; }
        public string[] newArr2 = new string[3];
        public Form2(int score1)
        {
            score = score1;
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

            var rndm = new Random();

            indx = rndm.Next(0, newArr.Length);

            List<char> ltrsLst = new List<char>(newArr[indx]);
            var rnd = new Random();
            while (ltrsLst.Count > 0)
            {
                int index = rnd.Next(0, ltrsLst.Count);
                label2.Text += Convert.ToString((ltrsLst[index]) + " ");
                ltrsLst.RemoveAt(index);
            }
            
            int k = 0;
            for (int i = 0; i < newArr2.Length; i++)
            {
                if (newArr[k] != newArr[indx])
                {
                    newArr2[i] = newArr[k];
                    k++;
                }
                else
                {
                    newArr2[i] = newArr[k + 1];
                    k += 2;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == newArr[indx])
            {
                if (click != 1)
                {
                    score++;
                }
            }           
                Form3 frm = new Form3(score);
                frm.newArr2 = newArr2;
                frm.Show();
                this.Hide();           
        }


        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = newArr[indx];
            click = 1;
        }
    }
}
