﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApp2{
    public partial class Form11 : Form
    {
        int click = 0;
        int score = 0;
        int indx;
        public Form11()
        {
            InitializeComponent();
        }
        static string[] wordsArray = new string[5] { "гітара", "пальто", "двері", "вікно", "лампа" };
        string[] newArr = new string[4];

        
         private void button2_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == wordsArray[indx])
            {
                if (click != 1)
                {
                    score++;                 
                }
            }
            Form2 frm = new Form2(score);
            frm.newArr = newArr;
            frm.Show();
            this.Hide();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            var rndm = new Random();

            indx = rndm.Next(0, wordsArray.Length);

            List<char> ltrsLst = new List<char>(wordsArray[indx]);
            var rnd = new Random();
            while (ltrsLst.Count > 0)
            {
                int index = rnd.Next(0, ltrsLst.Count);
                label2.Text += Convert.ToString((ltrsLst[index]) + " ");
                ltrsLst.RemoveAt(index);
            }

            int k = 0;
            for (int i = 0; i < newArr.Length; i++)
            {
                if (wordsArray[k] != wordsArray[indx])
                {
                    newArr[i] = wordsArray[k];
                    k++;
                }
                else
                {
                    newArr[i] = wordsArray[k + 1];
                    k += 2;
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            label4.Text = wordsArray[indx];
            click = 1;
        }
    }
}
